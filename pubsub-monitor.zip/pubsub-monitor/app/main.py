import os
import logging
from flask import Flask, jsonify
from google.cloud import pubsub_v1
from google.cloud import bigquery

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# ─── Configuración desde variables de entorno ───────────────────────────────
PROJECT_ID       = os.environ["GCP_PROJECT_ID"]
SUBSCRIPTION_ID  = os.environ["PUBSUB_SUBSCRIPTION_ID"]
BQ_DATASET       = os.environ["BQ_DATASET"]
BQ_TABLE         = os.environ["BQ_TABLE"]
MESSAGE_THRESHOLD = int(os.getenv("MESSAGE_THRESHOLD", "1"))


def get_pubsub_message_count(project_id: str, subscription_id: str) -> int:
    """
    Obtiene el número de mensajes disponibles en la suscripción de Pub/Sub
    usando pull con max_messages para contar sin consumir los mensajes.
    """
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, subscription_id)

    # Pull messages sin ACK para sólo contarlos
    response = subscriber.pull(
        request={
            "subscription": subscription_path,
            "max_messages": 1000,  # Ajusta según tu volumen esperado
            "return_immediately": True,
        }
    )

    count = len(response.received_messages)
    logger.info(f"Mensajes disponibles en '{subscription_id}': {count}")
    return count


def run_bigquery_count(project_id: str, dataset: str, table: str) -> int:
    """
    Ejecuta un COUNT(*) sobre la tabla de BigQuery y retorna el resultado.
    """
    client = bigquery.Client(project=project_id)
    query = f"SELECT COUNT(*) AS total FROM `{project_id}.{dataset}.{table}`"

    logger.info(f"Ejecutando query: {query}")
    query_job = client.query(query)
    results = query_job.result()

    for row in results:
        total = row["total"]
        logger.info(f"Total de registros en BigQuery '{dataset}.{table}': {total}")
        return total

    return 0


@app.route("/run", methods=["POST", "GET"])
def run_monitor():
    """
    Endpoint principal invocado por Cloud Scheduler cada 15 minutos.
    """
    try:
        # 1. Obtener número de mensajes en Pub/Sub
        message_count = get_pubsub_message_count(PROJECT_ID, SUBSCRIPTION_ID)

        if message_count <= MESSAGE_THRESHOLD:
            msg = (
                f"Mensajes en Pub/Sub ({message_count}) ≤ umbral ({MESSAGE_THRESHOLD}). "
                "No se ejecuta query."
            )
            logger.info(msg)
            return jsonify({"status": "skipped", "message": msg, "pubsub_count": message_count}), 200

        # 2. Si hay más mensajes que el umbral, ejecutar COUNT en BigQuery
        logger.info(
            f"Mensajes en Pub/Sub ({message_count}) > umbral ({MESSAGE_THRESHOLD}). "
            "Ejecutando query en BigQuery..."
        )
        bq_count = run_bigquery_count(PROJECT_ID, BQ_DATASET, BQ_TABLE)

        return jsonify({
            "status":        "executed",
            "pubsub_count":  message_count,
            "bq_total":      bq_count,
            "dataset":       BQ_DATASET,
            "table":         BQ_TABLE,
        }), 200

    except Exception as e:
        logger.exception("Error durante la ejecución del monitor")
        return jsonify({"status": "error", "error": str(e)}), 500


@app.route("/health", methods=["GET"])
def health():
    """Health check para Cloud Run."""
    return jsonify({"status": "ok"}), 200


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
