#!/usr/bin/env bash
# deploy.sh — Build, push y deploy completo de la solución
set -euo pipefail

# ─── Variables — ajusta antes de ejecutar ────────────────────────────────────
PROJECT_ID="${GCP_PROJECT_ID:?Debes exportar GCP_PROJECT_ID}"
REGION="${GCP_REGION:-us-central1}"
IMAGE_TAG="${IMAGE_TAG:-latest}"

IMAGE_PATH="${REGION}-docker.pkg.dev/${PROJECT_ID}/pubsub-monitor/app:${IMAGE_TAG}"

echo "╔══════════════════════════════════════════════════╗"
echo "║   PubSub Monitor — Deploy a Cloud Run + GCP      ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "  Proyecto : ${PROJECT_ID}"
echo "  Región   : ${REGION}"
echo "  Imagen   : ${IMAGE_PATH}"
echo ""

# 1. Autenticación de Docker con Artifact Registry
echo "▶ Configurando Docker para Artifact Registry..."
gcloud auth configure-docker "${REGION}-docker.pkg.dev" --quiet

# 2. Build de la imagen
echo "▶ Construyendo imagen Docker..."
docker build -t "${IMAGE_PATH}" ./app

# 3. Push de la imagen
echo "▶ Subiendo imagen a Artifact Registry..."
docker push "${IMAGE_PATH}"

# 4. Terraform
echo "▶ Inicializando Terraform..."
cd terraform
terraform init -upgrade

echo "▶ Planificando cambios..."
terraform plan -var="project_id=${PROJECT_ID}" -var="region=${REGION}"

echo ""
read -r -p "¿Aplicar los cambios? [s/N] " confirm
if [[ "${confirm,,}" == "s" ]]; then
  terraform apply -var="project_id=${PROJECT_ID}" -var="region=${REGION}" -auto-approve
  echo ""
  echo "✅ Deploy completado."
  terraform output
else
  echo "⚠️  Deploy cancelado."
fi
