output "cloud_run_url" {
  description = "URL del servicio de Cloud Run"
  value       = google_cloud_run_v2_service.monitor.uri
}

output "scheduler_job_name" {
  description = "Nombre del job de Cloud Scheduler"
  value       = google_cloud_scheduler_job.trigger.name
}

output "service_account_email" {
  description = "Email del Service Account de Cloud Run"
  value       = google_service_account.cloud_run_sa.email
}

output "docker_image_path" {
  description = "Path completo de la imagen en Artifact Registry"
  value       = "${var.region}-docker.pkg.dev/${var.project_id}/pubsub-monitor/app:latest"
}
