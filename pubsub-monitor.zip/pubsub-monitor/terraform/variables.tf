variable "project_id" {
  description = "ID del proyecto en GCP"
  type        = string
}

variable "region" {
  description = "Región de GCP para desplegar los recursos"
  type        = string
  default     = "us-central1"
}

variable "pubsub_subscription_id" {
  description = "ID de la suscripción de Pub/Sub a monitorear"
  type        = string
}

variable "bq_dataset" {
  description = "Dataset de BigQuery donde se ejecutará el COUNT"
  type        = string
}

variable "bq_table" {
  description = "Tabla de BigQuery sobre la que se ejecutará el COUNT"
  type        = string
}

variable "message_threshold" {
  description = "Número mínimo de mensajes para activar el query (default: 1)"
  type        = number
  default     = 1
}

variable "scheduler_timezone" {
  description = "Zona horaria para Cloud Scheduler"
  type        = string
  default     = "America/Mexico_City"
}
