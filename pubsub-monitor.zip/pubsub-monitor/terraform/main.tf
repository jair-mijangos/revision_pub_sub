terraform {
  required_version = ">= 1.5"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# ─── APIs requeridas ─────────────────────────────────────────────────────────
resource "google_project_service" "apis" {
  for_each = toset([
    "run.googleapis.com",
    "pubsub.googleapis.com",
    "bigquery.googleapis.com",
    "cloudscheduler.googleapis.com",
    "artifactregistry.googleapis.com",
    "iam.googleapis.com",
  ])
  service            = each.key
  disable_on_destroy = false
}

# ─── Service Account para Cloud Run ──────────────────────────────────────────
resource "google_service_account" "cloud_run_sa" {
  account_id   = "pubsub-monitor-sa"
  display_name = "Service Account - PubSub Monitor Cloud Run"
  depends_on   = [google_project_service.apis]
}

# Permisos: leer suscripciones de Pub/Sub
resource "google_project_iam_member" "pubsub_subscriber" {
  project = var.project_id
  role    = "roles/pubsub.subscriber"
  member  = "serviceAccount:${google_service_account.cloud_run_sa.email}"
}

# Permisos: leer datos de BigQuery
resource "google_project_iam_member" "bq_data_viewer" {
  project = var.project_id
  role    = "roles/bigquery.dataViewer"
  member  = "serviceAccount:${google_service_account.cloud_run_sa.email}"
}

# Permisos: ejecutar jobs de BigQuery
resource "google_project_iam_member" "bq_job_user" {
  project = var.project_id
  role    = "roles/bigquery.jobUser"
  member  = "serviceAccount:${google_service_account.cloud_run_sa.email}"
}

# ─── Artifact Registry para la imagen Docker ─────────────────────────────────
resource "google_artifact_registry_repository" "repo" {
  location      = var.region
  repository_id = "pubsub-monitor"
  format        = "DOCKER"
  description   = "Repositorio Docker para el monitor de Pub/Sub"
  depends_on    = [google_project_service.apis]
}

# ─── Cloud Run Service ────────────────────────────────────────────────────────
resource "google_cloud_run_v2_service" "monitor" {
  name     = "pubsub-monitor"
  location = var.region

  template {
    service_account = google_service_account.cloud_run_sa.email

    scaling {
      min_instance_count = 0
      max_instance_count = 1
    }

    timeout = "120s"

    containers {
      image = "${var.region}-docker.pkg.dev/${var.project_id}/pubsub-monitor/app:latest"

      resources {
        limits = {
          cpu    = "1"
          memory = "512Mi"
        }
        cpu_idle = true
      }

      env {
        name  = "GCP_PROJECT_ID"
        value = var.project_id
      }
      env {
        name  = "PUBSUB_SUBSCRIPTION_ID"
        value = var.pubsub_subscription_id
      }
      env {
        name  = "BQ_DATASET"
        value = var.bq_dataset
      }
      env {
        name  = "BQ_TABLE"
        value = var.bq_table
      }
      env {
        name  = "MESSAGE_THRESHOLD"
        value = tostring(var.message_threshold)
      }
    }
  }

  depends_on = [
    google_project_service.apis,
    google_artifact_registry_repository.repo,
  ]
}

# ─── Service Account para Cloud Scheduler ────────────────────────────────────
resource "google_service_account" "scheduler_sa" {
  account_id   = "pubsub-monitor-scheduler-sa"
  display_name = "Service Account - Cloud Scheduler → Cloud Run"
  depends_on   = [google_project_service.apis]
}

# Permitir que el Scheduler invoque el servicio de Cloud Run
resource "google_cloud_run_v2_service_iam_member" "scheduler_invoker" {
  project  = google_cloud_run_v2_service.monitor.project
  location = google_cloud_run_v2_service.monitor.location
  name     = google_cloud_run_v2_service.monitor.name
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.scheduler_sa.email}"
}

# ─── Cloud Scheduler — cada 15 minutos ───────────────────────────────────────
resource "google_cloud_scheduler_job" "trigger" {
  name             = "pubsub-monitor-trigger"
  description      = "Dispara el monitor de Pub/Sub cada 15 minutos"
  schedule         = "*/15 * * * *"
  time_zone        = var.scheduler_timezone
  attempt_deadline = "180s"

  retry_config {
    retry_count = 3
  }

  http_target {
    http_method = "POST"
    uri         = "${google_cloud_run_v2_service.monitor.uri}/run"

    oidc_token {
      service_account_email = google_service_account.scheduler_sa.email
      audience              = google_cloud_run_v2_service.monitor.uri
    }
  }

  depends_on = [
    google_project_service.apis,
    google_cloud_run_v2_service.monitor,
  ]
}
