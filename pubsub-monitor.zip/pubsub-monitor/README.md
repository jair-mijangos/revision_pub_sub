# 🔍 PubSub Monitor — Cloud Run + Cloud Scheduler

Solución en GCP que monitorea el número de mensajes en una suscripción de
**Pub/Sub** y, si supera el umbral configurado, ejecuta un `COUNT(*)` en
**BigQuery**. El proceso se ejecuta automáticamente **cada 15 minutos**
mediante **Cloud Scheduler**.

---

## Arquitectura

```
Cloud Scheduler (*/15 min)
        │  POST /run  (OIDC auth)
        ▼
  Cloud Run Service
  ┌─────────────────────────────────┐
  │  1. Pull Pub/Sub subscription   │──► Pub/Sub
  │  2. if count > threshold:       │
  │     SELECT COUNT(*) FROM table  │──► BigQuery
  └─────────────────────────────────┘
```

### Componentes GCP

| Recurso | Nombre | Descripción |
|---|---|---|
| Cloud Run | `pubsub-monitor` | Servicio Python/Flask |
| Cloud Scheduler | `pubsub-monitor-trigger` | Cron cada 15 min |
| Artifact Registry | `pubsub-monitor` | Repositorio Docker |
| Service Account (Run) | `pubsub-monitor-sa` | Permisos Pub/Sub + BQ |
| Service Account (Scheduler) | `pubsub-monitor-scheduler-sa` | Invoca Cloud Run |

---

## Prerrequisitos

- [gcloud CLI](https://cloud.google.com/sdk/docs/install) configurado
- [Terraform](https://developer.hashicorp.com/terraform/install) >= 1.5
- [Docker](https://docs.docker.com/get-docker/)
- Proyecto GCP con billing activo
- Una suscripción de Pub/Sub existente
- Una tabla de BigQuery existente

---

## Despliegue rápido

### 1. Configurar variables de entorno

```bash
export GCP_PROJECT_ID="mi-proyecto-gcp"
export GCP_REGION="us-central1"   # opcional, default us-central1
```

### 2. Copiar y editar el archivo de variables de Terraform

```bash
cp terraform/terraform.tfvars.example terraform/terraform.tfvars
# Editar terraform/terraform.tfvars con tus valores reales
```

### 3. Ejecutar el script de deploy

```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh
```

El script:
1. Construye la imagen Docker
2. La sube a Artifact Registry
3. Ejecuta `terraform apply` para crear/actualizar todos los recursos

---

## Variables de Terraform

| Variable | Descripción | Default |
|---|---|---|
| `project_id` | ID del proyecto GCP | — |
| `region` | Región de despliegue | `us-central1` |
| `pubsub_subscription_id` | ID de la suscripción a monitorear | — |
| `bq_dataset` | Dataset de BigQuery | — |
| `bq_table` | Tabla de BigQuery | — |
| `message_threshold` | Umbral de mensajes (> N activa query) | `1` |
| `scheduler_timezone` | Zona horaria del cron | `America/Mexico_City` |

---

## Endpoints del servicio

| Endpoint | Método | Descripción |
|---|---|---|
| `/run` | POST / GET | Lógica principal (invocado por Scheduler) |
| `/health` | GET | Health check de Cloud Run |

### Respuesta `/run` — sin suficientes mensajes

```json
{
  "status": "skipped",
  "message": "Mensajes en Pub/Sub (0) ≤ umbral (1). No se ejecuta query.",
  "pubsub_count": 0
}
```

### Respuesta `/run` — query ejecutado

```json
{
  "status": "executed",
  "pubsub_count": 42,
  "bq_total": 1500,
  "dataset": "mi_dataset",
  "table": "mi_tabla"
}
```

---

## Estructura del proyecto

```
pubsub-monitor/
├── app/
│   ├── main.py           # Aplicación Flask principal
│   ├── requirements.txt  # Dependencias Python
│   └── Dockerfile        # Imagen para Cloud Run
├── terraform/
│   ├── main.tf           # Recursos GCP (Cloud Run, Scheduler, IAM…)
│   ├── variables.tf      # Definición de variables
│   ├── outputs.tf        # Outputs útiles post-deploy
│   └── terraform.tfvars.example
└── scripts/
    └── deploy.sh         # Script de build + deploy
```

---

## Permisos IAM creados

El Terraform crea automáticamente los permisos mínimos necesarios:

**Service Account de Cloud Run** (`pubsub-monitor-sa`):
- `roles/pubsub.subscriber` — leer mensajes de Pub/Sub
- `roles/bigquery.dataViewer` — leer datos de BigQuery
- `roles/bigquery.jobUser` — ejecutar queries

**Service Account de Scheduler** (`pubsub-monitor-scheduler-sa`):
- `roles/run.invoker` — invocar el servicio de Cloud Run

---

## Actualizar la imagen (re-deploy)

```bash
export GCP_PROJECT_ID="mi-proyecto-gcp"

# Build y push manual
REGION="us-central1"
IMAGE="${REGION}-docker.pkg.dev/${GCP_PROJECT_ID}/pubsub-monitor/app:latest"

docker build -t $IMAGE ./app
docker push $IMAGE

# Forzar nuevo deployment en Cloud Run
gcloud run services update pubsub-monitor \
  --region $REGION \
  --image $IMAGE
```

---

## Invocar manualmente

```bash
# Obtener la URL del servicio
SERVICE_URL=$(gcloud run services describe pubsub-monitor \
  --region us-central1 --format 'value(status.url)')

# Invocar con autenticación
curl -X POST "${SERVICE_URL}/run" \
  -H "Authorization: Bearer $(gcloud auth print-identity-token)"
```
